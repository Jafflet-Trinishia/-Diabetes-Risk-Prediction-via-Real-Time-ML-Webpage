from flask import Flask,render_template,request,redirect,url_for
from sklearn.ensemble import RandomForestClassifier
import pickle
import sqlite3
app=Flask(__name__)


@app.route('/dia_index.html')
def dia_index():
    return render_template('dia_index.html')

@app.route("/",methods=["GET","POST"])
def home():
    msg=None
    if(request.method=="POST"):
        username=request.form["username"]
        password=request.form["password"]
        first_name=request.form["first_name"]
        last_name=request.form["last_name"]
        birthday=request.form["birthday"]
        gender=request.form["gender"]
        email=request.form["email"]
        phone=request.form["phone"]
        conn=sqlite3.connect('signup.db')
        c=conn.cursor()
        c.execute("INSERT INTO student VALUES('"+username+"','"+password+"','"+first_name+"','"+last_name+"','"+birthday+"','"+gender+"','"+email+"','"+phone+"')")
        msg="Your account is created"
        conn.commit()
        conn.close()
        return redirect(url_for("log"))
##        return render_template("login.html")
        
    return render_template("singup.html",msg=msg)

@app.route("/login.html")
def log():
    return render_template("login.html")

@app.route("/login.html",methods=["GET","POST"])
def login():
    r=""
    msg=""
    if(request.method=="POST"):
        username=request.form["username"]
        password=request.form["password"]
        conn=sqlite3.connect('signup.db')
        c=conn.cursor()
        c.execute("select * from student where username='"+username+"' and password='"+password+"' ")
        r=c.fetchall()
        for i in r:
            if(username==i[0] and password==i[1]):
                return redirect(url_for("bmi"))
            else:
                print("Please Enter Valid Username and Password")
    


@app.route('/BMI.html',methods=['POST','GET'])
def bmi():
    if request.method=="POST":
        c1=float(request.form['30'])
        c2=int(request.form['31'])
        c3=round(c2 / (c1 * c1), 2)
        c3=str(c3)
        return render_template('BMI_Result.html',result=c3)
        return render_template('Diabetes_Predicetd.html')
    return render_template('BMI.html')


@app.route('/Diabetes.html',methods=['POST','GET'])
def diabetes():
    if request.method=="POST":
        model=pickle.load(open('diabetes.pickle','rb'))
        a1=float(request.form['1'])
        a2=float(request.form['2'])
        a3=float(request.form['3'])
        a4=float(request.form['4'])
        a5=float(request.form['5'])
        a6=float(request.form['6'])
        a7=float(request.form['7'])
        s=model.predict([[a1,a2,a3,a4,a5,a6,a7]])
        if s[0]==0:
            return render_template('Diabetes__Not_Predicetd.html')
        else:
            return render_template('Diabetes_Predicetd.html')
        #else:
            #return redirect('/predict_diabetes')
    return render_template('Diabetes.html')



@app.route('/Doctors.html')
def doctors():
    return render_template('Doctors.html')



@app.route("/index.html")
def about():
    return render_template("about.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login.html"))
    
if __name__=="__main__":
    app.run(debug=True)
